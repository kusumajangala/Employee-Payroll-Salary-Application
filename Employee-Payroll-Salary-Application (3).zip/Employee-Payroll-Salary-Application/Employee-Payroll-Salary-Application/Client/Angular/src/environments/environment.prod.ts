export const environment = {
  production: true,
  emailAPI: 'http://XXXXXX.com/contact-form.php',
  database: 'graphql' ,
  social: {
    fblink: 'https://www.facebook.com/elishconsulting',
    linkedin: 'YYYYYYYY',
    github: 'https://github.com/AmitXShukla',
    emailid: 'info@elishconsulting.com'
  },
  socialAuthEnabled: false,
  graphql: 'http://localhost:3000/graphql'
};
